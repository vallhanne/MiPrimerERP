package org.example;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;

import java.util.List;

public class HibernateUtils {

    private static final SessionFactory sessionFactory = buildSessionFactory();

    private static SessionFactory buildSessionFactory() {
        try {
            return new Configuration().configure().buildSessionFactory(
                    new StandardServiceRegistryBuilder().configure().build());
        
        } catch (Throwable ex) {
            System.err.println("Initial SessionFactory creation failed. " + ex);
            throw new ExceptionInInitializerError(ex);
        }
    }

    public static SessionFactory getSessionFactory() {
        return sessionFactory;
    }
    
    
    public static void iniciar() {
    	getSessionFactory();
    }

    
    //Canciones
    public static List<Object[]> buscarCancion(String campoFiltro, String filtro) {
    	List<Object[]> resultados = null;
    	try(Session session = HibernateUtils.getSessionFactory().openSession()) {
        	Transaction tx = session.beginTransaction();
        	
        	Query<Object[]> query = session.createQuery(
                    "SELECT track, album.title, album.artistId, artist.name, genre.name, mediaType.name " +
                    "FROM TrackClass track " +
                    "JOIN AlbumClass album ON track.albumId = album.albumId " +
                    "JOIN ArtistClass artist ON album.artistId = artist.artistId " +
                    "JOIN GenreClass genre ON track.genreId = genre.genreId " +
                    "JOIN MediaTypeClass mediaType ON track.mediaTypeId = mediaType.mediaTypeId " +
                    "WHERE "+campoFiltro+" = :filtro", Object[].class);

            query.setParameter("filtro", filtro);
            resultados = query.list();
            
            tx.commit();
        } catch (Exception e) {
            e.printStackTrace();
        }

		return resultados;
    }
    
    public static List<Object[]> buscarCancionPorNombre(String nombreCancion) {
    	return buscarCancion("track.name", nombreCancion);
    }
    
    public static List<Object[]> buscarCancionPorArtista(String nombreArtista) {
    	return buscarCancion("artist.name", nombreArtista);
    }
    
    public static List<Object[]> buscarCancionPorCompositor(String compositor) {
    	return buscarCancion("track.composer", compositor);
    }
    
    public static List<Object[]> buscarCancionPorAlbum(String nombreAlbum) {
    	return buscarCancion("album.title", nombreAlbum);
    }
    
    public static List<Object[]> buscarCancionPorGenero(String nombreGenero) {
        return buscarCancion("genre.name", nombreGenero);
    }
    
    public static List<Object[]> buscarCancionPorDuracion(String duracion) {
    	return buscarCancion("track.milliseconds", duracion);
    }
    
    public static List<Object[]> buscarCancionesEnPlaylist(String playlistId) {
    	/*SELECT t.Name, a.Title, t.Milliseconds
			FROM playlisttrack as p
			JOIN track as t ON p.TrackId = t.TrackId
			JOIN album as a ON t.AlbumId = a.albumId
			WHERE PlaylistId = 1;*/
    	
    	List<Object[]> resultados = null;
    	try(Session session = HibernateUtils.getSessionFactory().openSession()) {
        	Transaction tx = session.beginTransaction();
        	
        	Query<Object[]> query = session.createQuery("SELECT track.name, album.title, track.milliseconds " +
        			"FROM PlaylistTrackClass playlisttrack " +
        			"JOIN TrackClass track ON playlisttrack.trackId = track.trackId " +
        			"JOIN AlbumClass album ON track.albumId = album.albumId " +
        			"WHERE playlistId = :filtro", Object[].class);

            query.setParameter("filtro", playlistId);
            resultados = query.list();
            
            tx.commit();
        } catch (Exception e) {
            e.printStackTrace();
        }

		return resultados;
    }
      
    public void eliminarCancion(int idCancion) {
    	Transaction tx = null;
        try(Session session = HibernateUtils.getSessionFactory().openSession()) {
        	tx = session.beginTransaction();
            TrackClass track = session.get(TrackClass.class, idCancion);
            session.remove(track);
            tx.commit();
        } catch (Exception e) {
        	if (tx != null) tx.rollback();	//Si algo sale mal evitar inconsistencia
            e.printStackTrace();
        }
    }
    
    //Gestionar para la modificación de cualquier cambio
    public void modificarCancion(int idCancion, String nuevoNombre) {
    	Transaction tx = null;
        try(Session session = HibernateUtils.getSessionFactory().openSession()) {
        	tx = session.beginTransaction();
            TrackClass track = session.get(TrackClass.class, idCancion);
            track.setName(nuevoNombre);
            //session.update(track);	//Se supone que lo detecta automatico (?)
            tx.commit();
        } catch (Exception e) {
        	if (tx != null) tx.rollback();	//Si algo sale mal evitar inconsistencia
        }
    }
    
  //Gestionar para crear todos los campos necesarios, no solo de TrackClass
    public void agregarCancion(TrackClass nuevaCancion) {
    	Transaction tx = null;
        try(Session session = HibernateUtils.getSessionFactory().openSession()) {
        	tx = session.beginTransaction();
            session.persist(nuevaCancion);
            tx.commit();
        } catch (Exception e) {
        	if (tx != null) tx.rollback();	//Si algo sale mal evitar inconsistencia
        }
    }
    
    
    //Albumes
    public static List<Object[]> buscarAlbum(String campoFiltro, String filtro) {
    	List<Object[]> resultados = null;
    	try(Session session = HibernateUtils.getSessionFactory().openSession()) {
        	Transaction tx = session.beginTransaction();
        	
        	Query<Object[]> query = session.createQuery(
                    "SELECT album, artist.Name " +
                    "FROM AlbumClass album " +
                    "JOIN ArtistClass artist ON album.artistId = artist.artistId " +
                    "WHERE "+campoFiltro+" = :filtro", Object[].class);

            query.setParameter("filtro", filtro);
            resultados = query.list();
            
            tx.commit();
        } catch (Exception e) {
            e.printStackTrace();
        }

		return resultados;
    }
    
    public static List<Object[]> buscarAlbumPorNombre(String nombreAlbum) {
    	return buscarAlbum("album.title", nombreAlbum);
    }
    
    public static List<Object[]> buscarAlbumPorArtista(String nombreArtista) {
    	return buscarAlbum("artist.name", nombreArtista);
    }
    
    
    //Playlists
    //2 Y 4 NO SE MUESTRAN -> No hay logs en playlisttrack
    public static List<Object[]> buscarPlaylist(String campoFiltro, String filtro) {
    	List<Object[]> resultados = null;
    	try(Session session = HibernateUtils.getSessionFactory().openSession()) {
        	Transaction tx = session.beginTransaction();
        	
        	Query<Object[]> query = session.createQuery(
//        			SELECT pl.PlaylistId, pl.Name AS PlaylistName, SUM(t.Milliseconds) AS TotalMilliseconds
//        			FROM playlist pl
//        			JOIN playlisttrack plt ON pl.PlaylistId = plt.PlaylistId
//        			JOIN track t ON plt.TrackId = t.TrackId
//        			WHERE pl.PlaylistId = 1
//        			GROUP BY pl.PlaylistId, pl.Name;
                    "SELECT playlist, COALESCE(SUM(track.milliseconds), 0) " +
                    "FROM PlaylistClass playlist " +
                    "LEFT JOIN PlaylistTrackClass playlisttrack ON playlist.playlistId = playlisttrack.playlistId " +
                    "LEFT JOIN TrackClass track ON playlisttrack.trackId = track.trackId " +
                    "WHERE "+campoFiltro+" = :filtro " +
                    "GROUP BY playlist.playlistId, playlist.name", Object[].class);

            query.setParameter("filtro", filtro);
            resultados = query.list();
            
            tx.commit();
        } catch (Exception e) {
            e.printStackTrace();
        }

		return resultados;
    }
    
    public static List<Object[]> buscarPlaylistPorPlaylistId(String listaId) {
    	return buscarPlaylist("playlist.playlistId", listaId);
    }
    
    public static List<Object[]> buscarPlaylistPorNombre(String nombrePlaylist) {
    	return buscarPlaylist("playlist.name", nombrePlaylist);
    }
 
    //Busqueda reversa
    public static List<PlaylistClass> buscarPlaylistsConTrackId(String cancionId) {
    	List<PlaylistClass> resultados = null;
    	try(Session session = HibernateUtils.getSessionFactory().openSession()) {
        	Transaction tx = session.beginTransaction();
        	
        	Query<PlaylistClass> query = session.createQuery(
        			"SELECT playlist FROM PlaylistClass playlist " +
        			"JOIN PlaylistTrackClass playlisttrack ON playlist.playlistId = playlisttrack.playlistId " +
        			"JOIN TrackClass track ON track.trackId = playlisttrack.trackId " +
        			"WHERE track.trackId = :filtro", PlaylistClass.class);

            query.setParameter("filtro", cancionId);
            resultados = query.list();
            
            tx.commit();
        } catch (Exception e) {
            e.printStackTrace();
        }

		return resultados;
    }
    
    
    //Empleados
    public static List<EmployeeClass> buscarEmpleado(String campoFiltro, String filtro) {
    	List<EmployeeClass> resultados = null;
    	try(Session session = HibernateUtils.getSessionFactory().openSession()) {
        	Transaction tx = session.beginTransaction();
        	
        	Query<EmployeeClass> query = session.createQuery(
                    "SELECT employee " +
                    "FROM EmployeeClass employee " +
                    "WHERE "+campoFiltro+" = :filtro", EmployeeClass.class);

            query.setParameter("filtro", filtro);
            resultados = query.list();
            
            tx.commit();
        } catch (Exception e) {
            e.printStackTrace();
        }

		return resultados;
    }
    
    
    public static List<EmployeeClass> buscarEmpleadoPorApellido(String apellido){
    	return buscarEmpleado("employee.lastName", apellido);
    }
    
    public static List<EmployeeClass> buscarEmpleadoPorPuesto(String puesto){
    	return buscarEmpleado("employee.title", puesto);
    }
    
    public static List<EmployeeClass> buscarEmpleadoPorId(String employeeId) {
    	return buscarEmpleado("employee.employeeId", employeeId);
    }
    
    
    //Artistas
    public static List<ArtistClass> buscarArtista(String campoFiltro, String filtro) {
    	List<ArtistClass> resultados = null;
    	try(Session session = HibernateUtils.getSessionFactory().openSession()) {
        	Transaction tx = session.beginTransaction();
        	
        	Query<ArtistClass> query = session.createQuery(
                    "SELECT artist " +
                    "FROM ArtistClass artist" +
                    "WHERE "+campoFiltro+" = :filtro", ArtistClass.class);

            query.setParameter("filtro", filtro);
            resultados = query.list();
            
            tx.commit();
        } catch (Exception e) {
            e.printStackTrace();
        }

		return resultados;
    }
    
    
    //Clientes
    public static List<CustomerClass> buscarClientes(String campoFiltro, String filtro) {
    	List<CustomerClass> resultados = null;
    	try(Session session = HibernateUtils.getSessionFactory().openSession()) {
        	Transaction tx = session.beginTransaction();
        	
        	Query<CustomerClass> query = session.createQuery(
                    "SELECT customer " +
                    "FROM CustomerClass customer " +
                    "WHERE "+campoFiltro+" = :filtro", CustomerClass.class);

            query.setParameter("filtro", filtro);
            resultados = query.list();
            
            tx.commit();
        } catch (Exception e) {
            e.printStackTrace();
        }

		return resultados;
    }
    
    public static List<CustomerClass> buscarClientesPorApellido(String apellido) {
    	return buscarClientes("customer.lastName", apellido);
    }
    
    public static List<CustomerClass> buscarClientesPorId(String id) {
    	return buscarClientes("customer.customerId", id);
    }
    
    
    //Compras -> Facturacion
    //Operaciones auxiliares: Obtener listados de compras [INVOICELINE]
    //CUSTOMER:CUSTOMERID- INVOICE:INVOICEID
    //Formulario: Todo de Invoice + Cliente a partir de ID
    
    public static List<Object[]> buscarFactura(String campoFiltro, String filtro) {
    	List<Object[]> resultados = null;
    	try(Session session = HibernateUtils.getSessionFactory().openSession()) {
        	Transaction tx = session.beginTransaction();
        	
        	Query<Object[]> query = session.createQuery(
                    "SELECT invoice, customer.firstName, customer.lastName " +
                    "FROM InvoiceClass invoice " +
                    "JOIN CustomerClass customer ON " +
                    "invoice.customerId = customer.customerId " +
                    "WHERE "+campoFiltro+" = :filtro", Object[].class);

            query.setParameter("filtro", filtro);
            resultados = query.list();
            
            tx.commit();
        } catch (Exception e) {
            e.printStackTrace();
        }

		return resultados;
    }
    
    
    public static List<Object[]> buscarFacturaPorClienteId(String clienteId) {
    	return buscarFactura("invoice.customerId", clienteId);
    }
    
    public static List<Object[]> buscarFacturaPorFacturaId(String facturaId) {
    	return buscarFactura("invoice.invoiceId", facturaId);
    }
    
    public static List<Object[]> buscarLineasDeFactura(String facturaId) {
    	List<Object[]> resultados = null;
    	try(Session session = HibernateUtils.getSessionFactory().openSession()) {
        	Transaction tx = session.beginTransaction();
        	
        	Query<Object[]> query = session.createQuery(
        			"SELECT track.name, album.title, invoiceline.unitPrice, invoiceline.quantity, invoiceline.unitPrice*invoiceline.quantity " +
        			"FROM TrackClass track " + 
        			"JOIN AlbumClass album ON track.albumId = album.albumId " +
        			"JOIN InvoiceLineClass invoiceline ON track.trackId = invoiceline.trackId " +
                    "WHERE invoiceline.invoiceId = :filtro", Object[].class);

            query.setParameter("filtro", facturaId);
            resultados = query.list();
            
            tx.commit();
        } catch (Exception e) {
            e.printStackTrace();
        }

		return resultados;
    }
    
    
    //Generos
    public static List<GenreClass> buscarGeneros(String campoFiltro, String filtro) {
    	List<GenreClass> resultados = null;
    	try(Session session = HibernateUtils.getSessionFactory().openSession()) {
        	Transaction tx = session.beginTransaction();
        	
        	Query<GenreClass> query = session.createQuery(
                    "SELECT genre " +
                    "FROM GenreClass customer " +
                    "WHERE "+campoFiltro+" = :filtro", GenreClass.class);

            query.setParameter("filtro", filtro);
            resultados = query.list();
            
            tx.commit();
        } catch (Exception e) {
            e.printStackTrace();
        }

		return resultados;
    }
}